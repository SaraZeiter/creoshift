import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import Client from 'shopify-buy';

const client = Client.buildClient({
  storefrontAccessToken: '400fca11710f728421743b8ee3699d9f',
  domain: 'MyTaskStore.myshopify.com'
});

ReactDOM.render(
  <App client={client}/>,
  document.getElementById('root')
);
