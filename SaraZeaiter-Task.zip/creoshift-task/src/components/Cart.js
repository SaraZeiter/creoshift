import React, {Component} from 'react';
import LineItem from '../components/LineItem';

class Cart extends Component {
  constructor(props) {
    super(props);
    this.openCheckout = this.openCheckout.bind(this);
  }

  openCheckout() {
    window.open(this.props.checkout.webUrl);
  }

  render() {
    let line_items = this.props.checkout.lineItems.map((line_item) => {
      return (
        <LineItem
          updateQuantityInCart={this.props.updateQuantityInCart}
          removeLineItemInCart={this.props.removeLineItemInCart}
          key={line_item.id.toString()}
          line_item={line_item}
        />
      );
    });

    return (
      <div style={{ width:'50%', float:'right', position:'relative'}}>
        <div style={{width:'100%', height:'60px', justifyContent:'space-between', display:'flex'}}>
          <h3>Name</h3>
          <h3>Quantity</h3>
          <h3 style={{marginRight:'4%'}}>Price</h3>
        </div>
         <div>
          {line_items}
        </div>
        <div style={{padding:'3px 27px', width:'100%', height:'auto', backgroundColor:'#FAFAFA'}}>
         <h2>
           Total: <span>$ {this.props.checkout.totalPrice}</span>
         </h2>
         <h2>
           SubTotal: <span className="pricing">$ {this.props.checkout.subtotalPrice}</span>
         </h2>
         <h2>
           Discount: <span className="pricing">$ 0.00</span>
         </h2>
        </div>
      </div>)    
}
}
export default Cart;
