import React, { Component } from 'react';
import HairProduct from '../components/HairProduct';
class HairProducts extends Component {
  render() {
    let products = this.props.products.map((product) => {
      return (
        <HairProduct
          addVariantToCart={this.props.addVariantToCart}
          client={this.props.client}
          key={product.id.toString()}
          product={product}
        />
      );
    });

    return (
      <div style={{borderRight:'1px solid #FAFAFA', marginLeft:'2%', display:'inline-block', position:'relative', float:'left', width:'41%'}}>
        {products}
      </div>
    );
  }
}

export default HairProducts;
