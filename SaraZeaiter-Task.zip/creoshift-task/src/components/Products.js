import React, { Component } from 'react';
import Product from '../components/Product';
import Link from 'react-router-dom'
class Products extends Component {
  render() {
    let products = this.props.products.map((product) => {

      return (
        <Product
          addVariantToCart={this.props.addVariantToCart}
          client={this.props.client}
          key={product.id.toString()}
          product={product}
        />
      );
    });

    return (
      <div style={{borderRight:'1px solid #FAFAFA', marginLeft:'2%', display:'inline-block', position:'relative', float:'left', width:'41%'}}>
        {products}
      </div>
    );
  }
}

export default Products;
