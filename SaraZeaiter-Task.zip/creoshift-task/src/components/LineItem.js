import React, {Component} from 'react';

class LineItem extends Component {
  constructor(props) {
    super(props);

    this.decrementQuantity = this.decrementQuantity.bind(this);
    this.incrementQuantity = this.incrementQuantity.bind(this);
  }

  decrementQuantity(lineItemId) {
    const updatedQuantity = this.props.line_item.quantity - 1
    this.props.updateQuantityInCart(lineItemId, updatedQuantity);
  }

  incrementQuantity(lineItemId) {
    const updatedQuantity = this.props.line_item.quantity + 1
    this.props.updateQuantityInCart(lineItemId, updatedQuantity);
  }

  render() {
    return (
      <div style={{backgroundColor: '#FAFAFA', height:'50px', marginBottom:'10px', display:'flex', alignItems:'center'}}>
        <div style={{height:'50px', width:'auto', position:'relative', float:'left', alignItems:'center', display:'flex', marginRight:'5px'}}>
          <button className="Line-item__remove" onClick={()=> this.props.removeLineItemInCart(this.props.line_item.id)}>×</button>
        </div>
        <div style={{height:'50px', position:'relative', float:'left', width:'42%'}}>{this.props.line_item.variant.image ? <img   style={{verticalAlign:'middle', width:'50px', height:'50px', position:'relative', float:'left'}} src={this.props.line_item.variant.image.src} alt={`${this.props.line_item.title} product shot`}/> : null} 
          <h5 style={{position:'relative', float:'left', marginLeft:'14px', marginTop:'13px'}}>{this.props.line_item.title}</h5>
        </div>
        <div style={{width:'128px', height:'25px', display:'flex', alignItems:'center'}}>
          <button className="Line-item__quantity-update" onClick={() => this.incrementQuantity(this.props.line_item.id)}>+</button>
          <h5 style={{margin:'0px 3px'}}>{this.props.line_item.quantity}</h5>
          <button className="Line-item__quantity-update" onClick={() => this.decrementQuantity(this.props.line_item.id)}>-</button>
        </div>
        <h5 style={{position:'relative', float:'right', marginLeft:'18%'}}>
              { (this.props.line_item.quantity * this.props.line_item.variant.price).toFixed(2) }
        </h5>
      </div>
    
    );
  }
}

export default LineItem;
