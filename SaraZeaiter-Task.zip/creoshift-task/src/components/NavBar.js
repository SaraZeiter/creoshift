import React, { useContext } from 'react'
import { Link, BrowserRouter } from 'react-router-dom'
import arrow from '../images/arrow.png'

const visible=true
class NavBar extends React.Component{
	constructor(){
		super()
		this.state={
			width:'',
			height:'',
			display:'none',
			visible:true
	}
	
	}
	showList =(e) =>{
	this.setState({
		visible:true,
			width:'172px',
			height:'106px',
			display:'block'
	})
}

  render() {
    return (
    	<div style={{justifyContent:'space-between',display:'flex', backgroundColor:'#000000', width:'100%', height:'50px', marginBottom:'20px'}}>
          	<div style={{display:'flex'}}>
          	<BrowserRouter>
          		<Link to="/"><div><img style={{marginLeft:'19px', marginTop:'6px', width:'24px', height:'37px'}} src={arrow}/></div></Link>
          		</BrowserRouter>
          	<h3 style={{marginLeft:'30px', marginTop:'7px', color:'#ffffff'}}>POS</h3>
          	</div>
          	<div onClick={this.showList.bind(this)} style={{marginRight:'29px', marginTop:'11px', color:'#ffffff', position:'relative', float:'right'}}>Ghiwa MORTADA</div>
          	<div style={{position:'absolute', marginLeft:'88%', marginTop:'3%', width:this.state.width, height:this.state.height, display:this.state.display, backgroundColor:'#ffffff', boxShadow:' -2px 5px #DCDCDC', zIndex:'1111'}}>
          		<p>Sara Zeaiter</p>
          		<p>Elie Hajj</p>
          		<p>Tony Fayad</p>
          	</div>
        </div>
    	)
}}
export default NavBar
