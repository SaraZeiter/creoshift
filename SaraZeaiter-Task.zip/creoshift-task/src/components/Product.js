import React, {Component} from 'react';
import VariantSelector from '../components/VariantSelector';
import { Link, BrowserRouter } from 'react-router-dom'
 const productimg={
    width: '100px',
    height:'50px',
    position:'relative', 
    float:'left',
    backgrounPosition:'center',
}
class Product extends Component {
  constructor(props) {
    super(props);

    let defaultOptionValues = {};
    this.props.product.options.forEach((selector) => {
      defaultOptionValues[selector.name] = selector.values[0].value;
    });
    this.state = { selectedOptions: defaultOptionValues };
  }

  render() {
    let variantImage = this.state.selectedVariantImage || this.props.product.images[0]
    let variant = this.state.selectedVariant || this.props.product.variants[0]
    let variantQuantity = this.state.selectedVariantQuantity || 1
    let variantSelectors = this.props.product.options.map((option) => {
      return (
        <VariantSelector
          handleOptionChange={this.handleOptionChange}
          key={option.id.toString()}
          option={option}
        />
      );
    });
    return (
          <div style={{ marginRight:'25px', marginBottom:'2%', width:'280px', backgroundColor:'#FAFAFA', position:'relative', float:'left'}}>
            {this.props.product.images.length && this.props.product.productType == 'makeup'? 
              <img style={{width:'100px', height:'100px', verticalAlign:'middle', position:'relative', float:'left'}}  src={variantImage.src} alt={`${this.props.product.title} product shot`}/> : null}
                {this.props.product.productType == 'makeup'?
                  <div style={{position:'relative', width:'173px', float:'right'}}>
                    <h5 >{this.props.product.title}</h5>
                    <span>${variant.price}</span>
                    <div style={{float:'right'}}><button onClick={() => this.props.addVariantToCart(variant.id, variantQuantity)}>+</button></div>
                  </div>: null}
          </div>
    );
  }
}

export default Product;
