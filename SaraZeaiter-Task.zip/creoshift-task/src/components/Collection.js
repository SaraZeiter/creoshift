import React, { useContext, useEffect } from 'react'
import { Link } from 'react-router-dom'
import plus from '../images/md_5afbe35ff3ec9.jpg'
import minus from '../images/pngtree-vector-minus-icon-png-image_925716.jpg'
import hair from '../images/modern-girl-with-a-new-hairstyle-vector-1232649.jpg'
import makeup from '../images/free-makeup-vector.jpg'
import elect from '../images/unnamed.png'
import nails from '../images/depositphotos_274300548-stock-illustration-vector-hand-drawn-illustration-of.jpg'
import bath from '../images/86d6da18b37846d78f78d0c2791dcb5a.jpg'
import skin from '../images/images (1).png'

const Collections = () =>{
	return(
        	<div style={{borderRight:'1px solid #fafafa', display:'inherit', height:'auto', width:'43%', float:'left', marginLeft:'3%'}}>
          		<Link to="/makeup">
          			<div style={{marginBottom:'73px', position:'relative', float:'left', marginRight:'30px', display:'block', width:'150px', height:'auto'}}>
          				<img style={{height:'140px', width:'150px'}} src={makeup}/>
          				<h3 style={{textAlign:'center'}}>Makup</h3>
          			</div>
          		</Link>
         		<Link to="/hair">
          			<div style={{marginBottom:'73px', position:'relative',float:'left', marginRight:'30px', display:'block', width:'150px', height:'auto'}}>
          				<img style={{height:'140px', width:'150px'}} src={hair}/>
          				<h3 style={{textAlign:'center'}}>Hair</h3>
          			</div>
          		</Link>
          		<div style={{marginBottom:'73px', position:'relative', float:'left', marginRight:'30px', display:'block', width:'150px', height:'auto'}}>
          			<img style={{height:'140px', width:'150px'}} src={elect}/>
          			<h3 style={{textAlign:'center'}}>Electrical</h3>
          		</div>
          		<div style={{marginBottom:'73px', position:'relative', float:'left', marginRight:'30px', display:'block', width:'150px', height:'auto'}}>
          			<img style={{height:'140px', width:'150px'}} src={skin}/>
          			<h3 style={{textAlign:'center'}}>SkinCare</h3>
          		</div>
          		<div style={{marginBottom:'73px', position:'relative', float:'left', marginRight:'30px', display:'block', width:'150px', height:'auto'}}>
          			<img style={{height:'140px', width:'150px'}} src={nails}/>
          			<h3 style={{textAlign:'center'}}>Nails</h3>
          		</div>
          		<div style={{marginBottom:'73px',position:'relative', float:'left', marginRight:'30px', display:'block', width:'150px', height:'auto'}}>
          		<img style={{height:'140px', width:'150px'}} src={bath}/>
          		<h3 style={{textAlign:'center'}}>Bath and Body</h3>
          		</div>
        	</div>
	);
}

export default Collections